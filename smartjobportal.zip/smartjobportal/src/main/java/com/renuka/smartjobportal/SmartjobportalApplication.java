package com.renuka.smartjobportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartjobportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartjobportalApplication.class, args);
	}

}
