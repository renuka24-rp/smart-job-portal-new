package com.renuka.smartjobportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartjobportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
